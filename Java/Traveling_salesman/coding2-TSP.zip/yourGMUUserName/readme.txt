Delete this sample text and put the NAME, USERNAME, and G-NUMBER of EVERY student who worked on this project below. For example, if you are working alone, put YOUR name, username, and g-number.

Example:

Jane Suchandsuch
jsuchand
G00000000

John Soandso
jsoandso
G00000001