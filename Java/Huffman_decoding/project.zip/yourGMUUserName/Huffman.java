//************************************************
//************************************************

//No additional imports, make do with these

//streams are for reading/writing bytes
import java.io.FileInputStream;
import java.io.FileOutputStream;
//for bits used provided BitInputStream and BitOutputStream

//readers/writers are for reading/writing characters
import java.io.FileReader;
import java.io.FileWriter;

//parent of all checked I/O exceptions
import java.io.IOException;

//pretty much all the data structures
import java.util.*;

//************************************************
//************************************************


//the class with the main method
class Huffman {
	public static void main(String[] args) {
		if(args.length != 1) System.out.println("Usage: java Huffman <inputFile>");
		
		//your code... feel free to make classes, methods, anything you want/need
	}
}