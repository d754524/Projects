Diego Zegarra
Project 3 
G01234361
Lecture: 002